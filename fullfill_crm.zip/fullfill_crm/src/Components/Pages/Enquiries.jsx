import React from 'react'

function Enquiries() {
  return (
    <div>Enquiries</div>
  )
}

export default Enquiries